package main.java.pocetniEkran;

import com.sun.javafx.tk.TKStage;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import main.covidportal.enums.VrijednostSimptoma;
import main.covidportal.iznimke.BolestIstihSimptoma;
import main.covidportal.main.Glavna;
import main.covidportal.model.*;
import main.resources.BazaPodataka;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main extends Application {

    public static Stage mainStage;
    public static List<Zupanija> popisZupanija=new ArrayList<>();
    public static List<Simptom> popisSimptoma = new ArrayList<>();
    public static List<Osoba> popisOsoba= new ArrayList<>();
    public static List<Bolest> popisBolesti= new ArrayList<>();

    public static BazaPodataka bazaPodataka = new BazaPodataka();

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("pocetniEkran.fxml"));
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();
        mainStage=primaryStage;
    }

    public static Stage getMainStage() {
        return mainStage;
    }

    private static final Logger logger = LoggerFactory.getLogger(Main.class);
    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
        bazaPodataka.otvoriVezu();
        popisZupanija = bazaPodataka.getZupanije();
        popisSimptoma = bazaPodataka.getSimptomi();
        popisBolesti = bazaPodataka.getBolesti();
        popisOsoba = bazaPodataka.getOsobe();


        launch(args);
        bazaPodataka.zatvoriVezu();
    }

}


