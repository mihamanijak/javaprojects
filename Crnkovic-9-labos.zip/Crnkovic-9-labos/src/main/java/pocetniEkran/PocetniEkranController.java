package main.java.pocetniEkran;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class PocetniEkranController {
    @FXML
    public void prikaziEkranZaPretraguZupanija() throws IOException {
        Parent pretragaZupanijaFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "pretragaZupanija.fxml"));
        Scene pretragaZupanijaScene = new Scene(pretragaZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaZupanijaScene);
        Main.getMainStage().setTitle("Pretraga Županija");
        Main.getMainStage().show();

    }

    @FXML
    public void prikaziEkranZaPretraguOsoba() throws IOException {
        Parent pretragaOsobaFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "pretragaOsoba.fxml"));
        Scene pretragaOsobaScene = new Scene(pretragaOsobaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaOsobaScene);
        Main.getMainStage().setTitle("Pretraga osoba");
        Main.getMainStage().show();

    }

    @FXML
    public void prikaziEkranZaPretraguSimptoma() throws IOException {
        Parent pretragaSimptomaFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "pretragaSimptoma.fxml"));
        Scene pretragaSimptomaScene = new Scene(pretragaSimptomaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaSimptomaScene);
        Main.getMainStage().setTitle("Pretraga simptoma");
        Main.getMainStage().show();

    }

    @FXML
    public void prikaziEkranZaDodavanjeZupanije() throws IOException {
        Parent dodavanjeZupanijeFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "dodavanjeNoveZupanije.fxml"));
        Scene dodavanjeZupanijeScene = new Scene(dodavanjeZupanijeFrame, 600, 400);
        Main.getMainStage().setScene(dodavanjeZupanijeScene);
        Main.getMainStage().setTitle("Dodavanje županije");
        Main.getMainStage().show();

    }

    @FXML
    public void prikaziEkranZaDodavanjeVirusa() throws IOException {
        Parent dodavanjeVirusaFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "dodavanjeVirusa.fxml"));
        Scene dodavanjeBolestiScene = new Scene(dodavanjeVirusaFrame, 600, 400);
        Main.getMainStage().setScene(dodavanjeBolestiScene);
        Main.getMainStage().setTitle("Dodavanje virusa");
        Main.getMainStage().show();

    }

    @FXML
    public void prikaziEkranZaDodavanjeSimptoma() throws IOException {
        Parent dodavanjeSimptomaFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "dodavanjeSimptoma.fxml"));
        Scene dodavanjeSimptomaScene = new Scene(dodavanjeSimptomaFrame, 600, 400);
        Main.getMainStage().setScene(dodavanjeSimptomaScene);
        Main.getMainStage().setTitle("Dodavanje županije");
        Main.getMainStage().show();

    }

    public void prikaziEkranZaDodavanjeOsobe() throws IOException {
        Parent dodavanjeOsobeFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "dodavanjeNoveOsobe.fxml"));
        Scene dodavanjeOsobeScene = new Scene(dodavanjeOsobeFrame, 600, 400);
        Main.getMainStage().setScene(dodavanjeOsobeScene);
        Main.getMainStage().setTitle("Dodavanje osobe");
        Main.getMainStage().show();

    }

    public void prikaziEkranZaPretraguVirusa() throws IOException {
        Parent pretragaVirusaFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "pretragaVirusa.fxml"));
        Scene pretragaVirusaScene = new Scene(pretragaVirusaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaVirusaScene);
        Main.getMainStage().setTitle("Pretraga simptoma");
        Main.getMainStage().show();

    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }
}
