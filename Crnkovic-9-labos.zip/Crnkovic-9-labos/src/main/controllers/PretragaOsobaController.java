package main.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import main.covidportal.model.Osoba;
import main.java.pocetniEkran.Main;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class PretragaOsobaController {
    @FXML
    TableView<Osoba> tablicaOsoba;

    @FXML
    TableColumn<Osoba, String> ime = new TableColumn<>();

    @FXML
    TableColumn<Osoba, String> prezime = new TableColumn<>();

    @FXML
    TableColumn<Osoba, Integer> starost = new TableColumn<>();

    @FXML
    TextField imeOsobe;

    @FXML
    void pokreniPretragu(){
        String naziv=imeOsobe.getText();
        List<Osoba> filtriraneOsobe = Main.popisOsoba.stream()
                .filter(osoba -> osoba.getPrezime().contains(naziv)
                        || osoba.getIme().contains(naziv))
                .collect(Collectors.toList());

        ObservableList<Osoba> osobeUTablici= FXCollections.observableArrayList(filtriraneOsobe);
        tablicaOsoba.setItems(osobeUTablici);
    }

    @FXML
    public void initialize(){
        ime.setCellValueFactory(new PropertyValueFactory<>("ime"));
        prezime.setCellValueFactory(new PropertyValueFactory<>("prezime"));
        starost.setCellValueFactory(new PropertyValueFactory<>("dob"));

    }
}
