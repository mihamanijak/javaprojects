package main.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import main.covidportal.model.Bolest;
import main.java.pocetniEkran.Main;

import java.sql.SQLException;
import java.util.List;

public class BolestiSimptomaController {

    @FXML
    TableView<Bolest> bolesti;

    @FXML
    TableColumn<Bolest, String> nazivi;

    @FXML
    Text naslov;

    @FXML
    void initialize() throws SQLException {
        List<Bolest> bolestiSimptoma = Main.bazaPodataka.findBolestiSimptoma(
                PretragaSimptomaController.simptom);

        naslov.setText("Bolesti simptoma "+PretragaSimptomaController.simptom.getNaziv());
        nazivi.setCellValueFactory(new PropertyValueFactory<>("naziv"));

        ObservableList<Bolest> bolestObservableList = FXCollections.observableArrayList(bolestiSimptoma);
        bolesti.setItems(bolestObservableList);

    }
}
