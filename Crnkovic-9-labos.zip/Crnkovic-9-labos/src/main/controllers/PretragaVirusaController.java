package main.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import main.covidportal.model.Bolest;
import main.covidportal.model.Virus;
import main.java.pocetniEkran.Main;

import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;



public class PretragaVirusaController {

    @FXML
    TextField nazivVir;
    @FXML
    TableView<Bolest> tablicaVirusa;
    @FXML
    TableColumn<Bolest, String> nazivi;



    @FXML
    void pokreniPretragu() {
        String naziv = nazivVir.getText();
        List<Bolest> popisVirusa = Main.popisBolesti.stream()
                .filter(bolest -> bolest instanceof Virus)
                .filter(bolest -> bolest.getNaziv().contains(naziv))
                .collect(Collectors.toList());

        ObservableList<Bolest> bolestObservableList= FXCollections.observableArrayList(popisVirusa);
        tablicaVirusa.setItems(bolestObservableList);
    }

    @FXML
    void initialize(){
        nazivi.setCellValueFactory(new PropertyValueFactory<>("naziv"));
    }
}
