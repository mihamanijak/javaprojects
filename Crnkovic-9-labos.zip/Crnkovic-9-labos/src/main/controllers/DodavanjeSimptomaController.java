package main.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import main.covidportal.enums.VrijednostSimptoma;
import main.covidportal.model.Simptom;
import main.covidportal.model.Zupanija;
import main.java.pocetniEkran.Main;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Optional;

public class DodavanjeSimptomaController {

    @FXML
    private RadioButton vrijednostR;

    @FXML
    private RadioButton vrijednostS;

    @FXML
    private RadioButton vrijednostC;

    @FXML
    private TextField nazivSimp;

    private ToggleGroup toggleGroup= new ToggleGroup();

    @FXML
    public void zapisi(){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Dodavanje simptoma");
        try {
            RadioButton konacna = (RadioButton) toggleGroup.selectedToggleProperty().getValue();
            VrijednostSimptoma vrijednostSimptoma = VrijednostSimptoma.valueOf(konacna.getText());
            String naziv = nazivSimp.getText();
            Long id = Long.valueOf(Main.popisSimptoma.size() + 1);
            Simptom simptom = new Simptom(naziv, id, vrijednostSimptoma);
            Main.bazaPodataka.dodajSimptom(simptom);
            Main.popisSimptoma.add(simptom);
        }
        catch (IllegalArgumentException | SQLException ex){
            System.out.println("Greška u pisanju!");
            ex.printStackTrace();
            alert.setHeaderText("Simptom nije dodan!");
            alert.setContentText(ex.getMessage());
            alert.showAndWait();
        }

    }

    @FXML
    public void initialize(){

        vrijednostC.setToggleGroup(toggleGroup);
        vrijednostR.setToggleGroup(toggleGroup);
        vrijednostS.setToggleGroup(toggleGroup);

    }

}
