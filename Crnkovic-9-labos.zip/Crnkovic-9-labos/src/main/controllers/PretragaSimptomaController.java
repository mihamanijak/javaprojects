package main.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import main.covidportal.model.Simptom;
import main.java.pocetniEkran.Main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class PretragaSimptomaController {

    @FXML
    private TableView<Simptom> tablicaSimptoma;

    @FXML
    private TableColumn<Simptom, String> nazivi = new TableColumn<>("Nazivi simptoma");

    @FXML
    private TableColumn<Simptom, String> vrijednosti= new TableColumn<>("Vrijednosti");

    @FXML
    private TextField nazivSimp;

    public static Simptom simptom;

    @FXML
    void pokreniPretragu(){
        String naziv=nazivSimp.getText();
        List<Simptom> filtriraniSimptomi = Main.popisSimptoma.stream()
                .filter(simptom -> simptom.getNaziv().contains(naziv))
                .collect(Collectors.toList());

        ObservableList<Simptom> simptomObservableList =
                FXCollections.observableArrayList(filtriraniSimptomi);
        tablicaSimptoma.setItems(simptomObservableList);
    }

    @FXML
    void initialize(){
        nazivi.setCellValueFactory(new PropertyValueFactory<>("naziv"));
        vrijednosti.setCellValueFactory(new PropertyValueFactory<>("vrijednost"));
        tablicaSimptoma.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(javafx.scene.input.MouseEvent mouseEvent) {
                if(mouseEvent.isPrimaryButtonDown() && mouseEvent.getClickCount()==2){
                    simptom=tablicaSimptoma.getSelectionModel().getSelectedItem();
                    try {
                        prikaziBolestiSimptoma();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    @FXML
    public void prikaziBolestiSimptoma() throws IOException {
        Parent bolestiSimptomaFrame =
                FXMLLoader.load(getClass().getClassLoader().getResource(
                        "bolestiSimptoma.fxml"));
        Scene bolestiSimptomaScene = new Scene(bolestiSimptomaFrame, 600, 400);
        Stage stage = new Stage();
        stage.setScene(bolestiSimptomaScene);
        stage.setTitle("Bolesti simptoma");
        stage.show();

    }

}
