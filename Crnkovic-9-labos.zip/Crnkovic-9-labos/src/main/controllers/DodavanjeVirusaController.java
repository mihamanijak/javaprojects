package main.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import main.covidportal.model.Simptom;
import main.covidportal.model.Virus;
import main.covidportal.model.Zupanija;
import main.java.pocetniEkran.Main;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

public class DodavanjeVirusaController {

    @FXML
    ListView<CheckBox> simptomiVir;

    @FXML
    TextField nazivVir;

    private Map<CheckBox, Simptom> mapaSimptoma = new HashMap<CheckBox, Simptom>();

    @FXML
    public void zapisi() throws SQLException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Dodavanje virusa");
        String naziv = nazivVir.getText();
        Set<Simptom> simptomi = new HashSet<>();
        ObservableList<CheckBox> checkBoxes = simptomiVir.getItems();
        Long id = Long.valueOf(Main.popisBolesti.size()+1);

        for (CheckBox checkBox : checkBoxes){
            if(checkBox.isSelected()){
                simptomi.add(mapaSimptoma.get(checkBox));
            }
        }

        Virus virus = new Virus(naziv, id, simptomi);
        Main.bazaPodataka.dodajBolest(virus);
        Main.popisBolesti.add(virus);

        try (BufferedWriter virusWriter = new BufferedWriter(
                new FileWriter("dat\\bolesti.txt", true))){
            virusWriter.newLine();
            virusWriter.write("2");
            virusWriter.newLine();
            virusWriter.write(String.valueOf(virus.getId()));
            virusWriter.newLine();
            virusWriter.write(virus.getNaziv());
            virusWriter.newLine();
            virusWriter.write(String.valueOf(virus.getSimptomi().size()));
            virusWriter.newLine();
            List<Simptom> listaSimptomaVirusa= virus.getSimptomi().stream().collect(Collectors.toList());
            List<Simptom> listaPopisaSimptoma= Main.popisSimptoma.stream().collect(Collectors.toList());
            for (int i=0; i<listaSimptomaVirusa.size(); i=i+1){
                for (int j=0; j<listaPopisaSimptoma.size(); j=j+1){
                    if (listaSimptomaVirusa.get(i).equals(listaPopisaSimptoma.get(j))){
                        virusWriter.write(String.valueOf(j+1));
                        if(i<listaSimptomaVirusa.size()-1){
                            virusWriter.write(",");
                        }
                    }
                }
            }

            alert.setHeaderText("Virus uspješno dodan!");
            alert.showAndWait();
        }
        catch(IOException ex){
            System.out.println("Greška u pisanju!");
            ex.printStackTrace();
            alert.setHeaderText("Virus nije dodan!");
            alert.setContentText(ex.getMessage());
            alert.showAndWait();
        }



    }

    @FXML
    public void initialize(){
        List<String> naziviSimptoma = Main.popisSimptoma.stream()
                .map(bolest -> bolest.getNaziv())
                .collect(Collectors.toList());

        List<CheckBox> checkBoxes= new ArrayList<>();
        for (String naziv : naziviSimptoma){
            checkBoxes.add(new CheckBox(naziv));
        }

        for (CheckBox checkBox : checkBoxes){
            for (Simptom simptom : Main.popisSimptoma){
                if(checkBox.getText().equals(simptom.getNaziv())){
                    mapaSimptoma.put(checkBox, simptom);
                    break;
                }
            }
        }

        ObservableList<CheckBox> observableList= FXCollections.observableArrayList(checkBoxes);
        simptomiVir.setItems(observableList);
    }

}
