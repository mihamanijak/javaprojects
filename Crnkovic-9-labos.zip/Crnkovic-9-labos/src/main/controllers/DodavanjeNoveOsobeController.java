package main.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import main.covidportal.model.Bolest;
import main.covidportal.model.Osoba;
import main.covidportal.model.Zupanija;
import main.java.pocetniEkran.Main;

import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

public class DodavanjeNoveOsobeController {

    @FXML
    private ListView<CheckBox> popisKontakta;

    @FXML
    private ListView<RadioButton> zupanija;

    @FXML
    private TextField ime;

    @FXML
    private TextField prezime;

    @FXML
    private TextField starost;

    @FXML
    private ListView<RadioButton> bolest;

    private ToggleGroup toggleGroupZupanija = new ToggleGroup();
    private ToggleGroup toggleGroupBolesti = new ToggleGroup();

    @FXML
    public void zapisi() throws SQLException {
        Map<CheckBox, Osoba> mapaOsoba = new HashMap<>();
        int i=0;
        RadioButton odabirZup = (RadioButton) toggleGroupZupanija.selectedToggleProperty().getValue();
        RadioButton odabirBol = (RadioButton) toggleGroupBolesti.selectedToggleProperty().getValue();
        for (CheckBox checkBox : popisKontakta.getItems()){
            mapaOsoba.put(checkBox, Main.popisOsoba.get(i));
            i=i+1;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Dodavanje osobe");
        Osoba.Builder builder = new Osoba.Builder(ime.getText());
        try {
            for (Zupanija zup : Main.popisZupanija){
                if(zup.getNaziv().equals(odabirZup.getText())){
                    builder.setZupanija(zup);
                    break;
                }
            }
            for (Bolest bol : Main.popisBolesti){
                if(bol.getId().equals(odabirBol.getText())){
                    builder.setZarazenBolescu(bol);
                    break;
                }
            }
            builder.setPrezime(prezime.getText())
                    .setDatumRodjenja(starost.getText());

            List<Osoba> kontakti = new ArrayList<>();
            for (CheckBox checkBox : popisKontakta.getItems()){
                if (checkBox.isSelected()){
                    kontakti.add(mapaOsoba.get(checkBox));
                }
            }
            builder.setKontaktiraneOsobe(kontakti);
        }
        catch(NumberFormatException ex){
            ex.printStackTrace();
            alert.setHeaderText("Osoba nije dodana!");
            alert.setContentText(ex.getMessage());
            alert.showAndWait();
        }
        builder.setId(Long.valueOf(Main.popisOsoba.size()+1));
        Osoba osoba = builder.build();
        Main.bazaPodataka.dodajOsobu(osoba);
        Main.popisOsoba.add(osoba);


    }


    @FXML
    public void initialize(){
        List<String> imena = Main.popisOsoba.stream()
                .map(osoba -> osoba.getIme()+" "+osoba.getPrezime())
                .collect(Collectors.toList());
        List<String> imenaZupanija = Main.popisZupanija.stream()
                .map(zupanija -> zupanija.getNaziv())
                .collect(Collectors.toList());
        List<String> imenaBolesti = Main.popisBolesti.stream()
                .map(bolest -> bolest.getNaziv())
                .collect(Collectors.toList());

        List<RadioButton> radioButtonsBolesti = new ArrayList<>();
        for (String ime : imenaBolesti){
            radioButtonsBolesti.add(new RadioButton(ime));
        }

        for (RadioButton radioButton : radioButtonsBolesti){
            radioButton.setToggleGroup(toggleGroupBolesti);
        }

        List<RadioButton> radioButtonsZupanija = new ArrayList<>();
        for (String ime : imenaZupanija){
            radioButtonsZupanija.add(new RadioButton(ime));
        }

        for (RadioButton radioButton : radioButtonsZupanija){
            radioButton.setToggleGroup(toggleGroupZupanija);
        }

        List<CheckBox> checkBoxes = new ArrayList<>();
        for (String ime : imena) {
            checkBoxes.add(new CheckBox(ime));
        }

        ObservableList<CheckBox> observableKontakti = FXCollections.observableArrayList(checkBoxes);
        popisKontakta.setItems(observableKontakti);

        ObservableList<RadioButton> observableZupanije = FXCollections.observableArrayList(radioButtonsZupanija);
        zupanija.setItems(observableZupanije);

        ObservableList<RadioButton> observableBolesti = FXCollections.observableArrayList(radioButtonsBolesti);
        bolest.setItems(observableBolesti);
    }

}

