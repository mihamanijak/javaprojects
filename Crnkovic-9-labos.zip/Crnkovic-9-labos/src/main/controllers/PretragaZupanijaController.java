package main.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import main.covidportal.model.Zupanija;
import main.java.pocetniEkran.Main;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class PretragaZupanijaController {
    @FXML
    private TextField nazivZup;

    @FXML
    private TableView<Zupanija> tablicaZupanija;

    @FXML
    private TableColumn<Zupanija, String> nazivi = new TableColumn<>("Naziv županije");

    @FXML
    private TableColumn<Zupanija, Integer> brStanovnika = new TableColumn<>("Broj stanovnika");

    @FXML
    private TableColumn<Zupanija, Integer> brZarazenih = new TableColumn<>("Broj zaraženih");


    @FXML
    void pokreniPretragu(){
        String naziv=nazivZup.getText();
        List<Zupanija> filtriraneZupanije=new ArrayList<>();

        filtriraneZupanije=Main.popisZupanija.stream()
                .filter(zupanija -> zupanija.getNaziv().contains(naziv))
                .collect(Collectors.toList());
        /*for (Zupanija zupanija : Main.popisZupanija){
            if(zupanija.getNaziv().contains(naziv)){
                filtriraneZupanije.add(zupanija);
            }
        }*/
        ObservableList<Zupanija> zupanijeUTablici= FXCollections.observableArrayList(filtriraneZupanije);
        tablicaZupanija.setItems(zupanijeUTablici);
    }

    @FXML
    public void initialize(){
        nazivi.setCellValueFactory(new PropertyValueFactory<>("naziv"));
        brStanovnika.setCellValueFactory(new PropertyValueFactory<>("brojStanovnika"));
        brZarazenih.setCellValueFactory(new PropertyValueFactory<>("brojZarazenih"));

    }
}
