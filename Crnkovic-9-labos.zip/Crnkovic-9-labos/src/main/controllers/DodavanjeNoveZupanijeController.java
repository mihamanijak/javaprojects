package main.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import main.covidportal.model.Zupanija;
import main.java.pocetniEkran.Main;

import javax.swing.*;
import javax.swing.text.html.Option;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Optional;

public class DodavanjeNoveZupanijeController {

    @FXML
    TextField nazivZup;

    @FXML
    TextField brStan;

    @FXML
    TextField brZar;

    @FXML
    public void zapisi(){
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Dodavanje županije");
        Zupanija zupanija = null;
        try {
            String naziv = nazivZup.getText();
            Integer brStanovnika = Integer.parseInt(brStan.getText());
            Integer brZarazenih = Integer.parseInt(brZar.getText());
            Long id = Long.valueOf(Main.popisZupanija.size() + 1);
            zupanija = new Zupanija(naziv, id, brStanovnika, brZarazenih);
            Main.bazaPodataka.dodajZupaniju(zupanija);
            Main.popisZupanija.add(zupanija);
        }
        catch(NumberFormatException | SQLException ex){
            System.out.println("Greška u pisanju!");
            ex.printStackTrace();
            alert.setHeaderText("Županija nije dodana!");
            alert.setContentText(ex.getMessage());
            alert.showAndWait();
        }

    }

    @FXML
    public void initialize(){};

}
