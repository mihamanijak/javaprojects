package main.covidportal.sort;

import main.covidportal.model.Zupanija;

import java.util.*;


/**
 * Overridea metodu compare pomoću koje uspoređujemo postotak zaraženih osoba u županiji
 *
 */
public class CovidSorter implements Comparator<Zupanija> {

    @Override
    public int compare(Zupanija o1, Zupanija o2) {
        if (o1.getPostotakZarazenih()>o2.getPostotakZarazenih()){
            return 1;
        }
        return 0;
    }

    /*public Set<Zupanija> sortZupanije(Set<Zupanija> popisZupanija){
        popisZupanija.stream().sorted(this::compare);
        return popisZupanija;
    }*/
}
