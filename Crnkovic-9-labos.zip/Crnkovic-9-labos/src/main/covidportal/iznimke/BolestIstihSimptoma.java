package main.covidportal.iznimke;

/**
 * javlja grešku da postoje dvije bolesti istih simptoma
 *
 */
public class BolestIstihSimptoma extends RuntimeException{

    /**
     * Inicijalizira poruku iznimke
     * @param message poruka iznimke
     */
    public BolestIstihSimptoma(String message) {
        super(message);
    }

    public BolestIstihSimptoma(String message, Throwable cause) {
        super(message, cause);
    }

    public BolestIstihSimptoma(Throwable cause) {
        super(cause);
    }
}
