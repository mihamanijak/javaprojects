package main.covidportal.iznimke;

/**
 * javlja grešku da je u kontaktima osobe duplikat
 */
public class DuplikatiKontaktiraneOsobe extends Exception {
    /**
     * Inicijalizira poruku iznimke
     * @param message poruka iznimke
     */
    public DuplikatiKontaktiraneOsobe(String message) {
        super(message);
    }

    public DuplikatiKontaktiraneOsobe(String message, Throwable cause) {
        super(message, cause);
    }

    public DuplikatiKontaktiraneOsobe(Throwable cause) {
        super(cause);
    }
}
