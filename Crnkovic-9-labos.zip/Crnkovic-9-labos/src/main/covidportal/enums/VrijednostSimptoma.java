package main.covidportal.enums;

/**
 * Predstavlja vrijednost simptoma (RIJETKO, SREDNJE, ČESTO)
 *
 */
public enum VrijednostSimptoma {
    RIJETKO("RIJETKO"), SREDNJE("SREDNJE"), ČESTO("ČESTO"),
    PRODUKTIVNI("Produktivni"), VISOKA("Visoka"), INTENZIVNO("Intenzivno"),
    JAKA("Jaka");

    String vrSimptoma;

    /**
     * Inicijalizira podatak o vrijednosti simptoma
     * @param vrSimptoma podatak o vrijednosti simptoma
     *
     */
    VrijednostSimptoma(String vrSimptoma) {
        this.vrSimptoma = vrSimptoma;
    }

    public String getVrSimptoma() {
        return vrSimptoma;
    }
}
