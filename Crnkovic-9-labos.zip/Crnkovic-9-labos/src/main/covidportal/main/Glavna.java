package main.covidportal.main;

import main.covidportal.enums.VrijednostSimptoma;
import main.covidportal.genericsi.KlinikaZaInfektiveBolesti;
import main.covidportal.iznimke.BolestIstihSimptoma;
import main.covidportal.iznimke.DuplikatiKontaktiraneOsobe;
import main.covidportal.model.*;
import main.covidportal.sort.CovidSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Sadrži main metodu i sve metode koje se u njoj pozivaju.
 *
 */
public class Glavna {

    private static final Logger logger = LoggerFactory.getLogger(Glavna.class);

    public static void main(String[] args) throws IOException {

        logger.info("Pokrenut je program!");

        Scanner unos = new Scanner(System.in);
        //File zupanije= new File("C:\\Users\\38599\\Desktop\\Crnkovic-6\\dat\\zupanije.txt");


        Set<Zupanija> popisZupanija = new HashSet<>();
        Set<Simptom> popisSimptoma = new HashSet<>();
        Set<Bolest> popisBolesti = new HashSet<>();
        List<Osoba> popisOsoba = new ArrayList<>();
        Map<Bolest, List<Osoba>> mapaBolesti= new HashMap<>();

        try (BufferedReader zupanijeReader = new BufferedReader(new FileReader("dat\\zupanije.txt"));) {
            logger.info("Unose se županije!");
            while (zupanijeReader.ready()){
                popisZupanija.add(unosZupanije(zupanijeReader));
            }
        } catch(IOException ex){
            System.out.println("Greška u čitanju datoteke!");
            logger.error(ex.getMessage());
        }

        ispisZupanija(popisZupanija);

        try (BufferedReader simptomiReader= new BufferedReader(new FileReader("dat\\simptomi.txt"))){
            logger.info("Unose se simptomi!");
            while (simptomiReader.ready()){
                popisSimptoma.add(unosSimptoma(simptomiReader));
            }
        } catch(IOException ex){
            System.out.println("Greška u čitanju datoteke!");
            logger.error(ex.getMessage());
        }


        try (BufferedReader bolestiReader= new BufferedReader(new FileReader("dat\\bolesti.txt"))) {
            logger.info("Unose se bolesti!");
            while(bolestiReader.ready()){
                popisBolesti.add(unosBolesti(bolestiReader, popisSimptoma, popisBolesti));
            }
        } catch (IOException ex){
            System.out.println("Greška u čitanju datoteke!");
            logger.error(ex.getMessage());
        }

        try (BufferedReader osobeReader= new BufferedReader(new FileReader("dat\\osobe.txt"))){
            logger.info("Unose se osobe!");
            while (osobeReader.ready()) {
                Osoba osoba = unosOsobe(osobeReader, popisZupanija, popisBolesti, popisOsoba);
                popisOsoba.add(osoba);
                if (!popisOsoba.isEmpty()) {
                    osoba.upari();
                }
            }
        } catch (IOException ex){
            System.out.println("Greška u čitanju datoteke!");
            logger.error(ex.getMessage());
        }


        logger.info("Ispisuje se popis unesenih osoba!");

        popisOsoba(popisOsoba);

        dodajUMapu(popisBolesti, popisOsoba, mapaBolesti);
        ispisMape(popisBolesti, mapaBolesti);

        Zupanija zariste=popisZupanija.stream().max(new CovidSorter()).get();
        System.out.print("Najviši postotak zaraženih ima županija: ");
        System.out.println(zariste.getNaziv()+": "+String.format("%.2f", zariste.getPostotakZarazenih())+"%");

        List<Virus> popisVirusa = new ArrayList<>();
        for (Bolest bolest : popisBolesti) {
            if (bolest instanceof Virus){
                popisVirusa.add((Virus) bolest);
            }
        }

        KlinikaZaInfektiveBolesti<Virus, Osoba> klinika= new KlinikaZaInfektiveBolesti<>
                (popisVirusa, popisOsoba);
        usporedbaVremenaSortiranja(klinika);

        List<Osoba> filtriraneOsobe = filtrirajOsobe(popisOsoba, unos).get();
        for(Osoba o : filtriraneOsobe){
            System.out.println(o.getPrezime() + " " + o.getIme());
        }
        brojSimptomaBolesti(popisBolesti);

        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("dat\\zupanije1.dat"))){
            for (Zupanija zupanija : popisZupanija){
                if(zupanija.getPostotakZarazenih()>2){
                    outputStream.writeObject(zupanija);
                }
            }
        } catch (IOException ex){
            System.out.println("Greška u čitanju datoteke!");
            logger.error(ex.getMessage());
        }


    }

    private static void popisOsoba(List<Osoba> popisOsoba) {
        System.out.println("Popis osoba:");
        for (int i = 0; i < popisOsoba.size(); i = i + 1) {
            System.out.println("");
            System.out.println("Ime i prezime: " + popisOsoba.get(i).getIme()
                    + " " + popisOsoba.get(i).getPrezime());
            System.out.println("Starost: " + popisOsoba.get(i).getDob());
            System.out.println("Županija prebivališta: " + popisOsoba.get(i).getZupanija().getNaziv());
            System.out.println("Zarazen bolešću: " + popisOsoba.get(i).getZarazenBolescu().getNaziv());
            System.out.println("Kontaktirane osobe:");
            if (popisOsoba.get(i).getKontaktiraneOsobe().size() == 0) {
                System.out.println("Nema kontaktiranih osoba.");
            } else {
                ispisOsoba(popisOsoba.get(i).getKontaktiraneOsobe());
            }
        }
    }

    /**
     * Uspoređuje vrijeme sortiranja liste virusa u klasi KlinikaZaInfektivneBolesti pomoću lambdi
     * i bez lambde(pomoću dvije for petlje), ispisuje sortirane liste i vremena sortiranja
     * @param klinika podatak o klinici koja sadrži listu virusa
     */
    private static void usporedbaVremenaSortiranja(KlinikaZaInfektiveBolesti<Virus, Osoba> klinika) {
        Instant start = Instant.now();
        klinika.sortViruseLambda();
        Instant end = Instant.now();
        System.out.println("Vrijeme sortiranja pomoću lambde: "+ Duration.between(start, end));
        klinika.printVirusi();
        Collections.shuffle(klinika.getVirusi());
        start = Instant.now();
        klinika.sortViruse();
        end = Instant.now();
        System.out.println("Vrijeme sortiranja bez lambde: "+ Duration.between(start, end));
        klinika.printVirusi();
    }

    /**
     * Prima popis bolesti i ispisuje koliko svaka bolest ima simptoma
     * @param popisBolesti podatak o popisu bolesti
     */
    private static void brojSimptomaBolesti(Set<Bolest> popisBolesti) {
        List<String> nazivi = popisBolesti.stream()
                .map(Bolest::getNaziv)
                .collect(Collectors.toList());
        List<Integer> brojeviSimptoma = popisBolesti.stream()
                .map(bolest -> bolest.getSimptomi().size())
                .collect(Collectors.toList());
        Map<String, Integer> bolestiSimptomi= new HashMap<>();

        for(int i=0; i< nazivi.size(); i=i+1){
            System.out.println("Broj simptoma za "+nazivi.get(i)+": "+brojeviSimptoma.get(i));
        }
    }

    /**
     * Traži osobe koje sadrže zadani string.
     * @param popisOsoba podatak o popisu osoba
     * @param unos scanner koji učitava zadani string
     * @return objekt tipa optional
     */
    private static Optional<List> filtrirajOsobe(List<Osoba> popisOsoba, Scanner unos) {
        System.out.println("Unesite string za pretragu prezimena: ");
        String prezime=unos.nextLine();
        List<Osoba> filtriraneOsobe = popisOsoba.stream()
                .filter(osoba -> osoba.getPrezime().contains(prezime))
                .collect(Collectors.toList());
        Optional<List> optionalOsobe = Optional.ofNullable(filtriraneOsobe);

        return optionalOsobe;
    }

    /**
     * Ispisuje mapu koja sadrži podatke o tome koja osoba ima koju bolest
     * @param popisBolesti bolesti koje se koriste kao ključ mape
     * @param mapaBolesti mapa koja sadrži podatke o tome koja osoba ima koju bolest
     *
     */
    private static void ispisMape(Set<Bolest> popisBolesti, Map<Bolest, List<Osoba>> mapaBolesti) {
        for(Bolest bolest : popisBolesti){
            System.out.println("Osobe koje imaju "+bolest.getNaziv()+": ");
            ispisOsoba(mapaBolesti.get(bolest));
        }
    }

    /**
     * Dodaje element u mapu pod određenim ključem
     * @param popisBolesti popis bolesti koje se koriste kao ključ mape
     * @param popisOsoba popis osoba koje se dodaju u listu osoba
     * @param mapaBolesti mapa u koju se dodaje lista osoba pod ključem bolesti
     *
     */
    private static void dodajUMapu(Set<Bolest> popisBolesti, List<Osoba> popisOsoba, Map<Bolest, List<Osoba>> mapaBolesti) {
        for (Bolest bolest : popisBolesti){
            List<Osoba> tmpOsobe= new ArrayList<>();
            for (Osoba osoba : popisOsoba){
                if (osoba.getZarazenBolescu().equals(bolest)){
                    tmpOsobe.add(osoba);
                }
            }
            mapaBolesti.put(bolest, tmpOsobe);
        }
    }

   /* private static String getPunoIme(List<Osoba> popisOsoba){
        for (int i=0; i<popisOsoba.size(); i=i+1){
            return popisOsoba.get(i).getIme()+" "+popisOsoba.get(i).getPrezime();
        }
    }*/

    /**
     * Dohvaća Integer iz unosa
     * @param unos scanner od kojeg se dohvaća Integer
     * @return dohvaćeni Integer
     */
    private static Integer getInteger(Scanner unos) {
        Integer broj;
        try {
            do{
                broj = unos.nextInt();
            } while (broj < 1);
        }
        catch (InputMismatchException ex){
            logger.error(ex.getMessage());
            System.out.println("Unesen je string umjesto broja! Pokušajte ponovno!");
            unos.nextLine();
            broj=getInteger(unos);
        }
        return broj;
    }


    /**
     * Traži unos podataka o osobi i vraća novu osobu koja se stvara pomoću builder patterna.
     * @param unos Scanner koji traži unos podataka
     * @param popisZupanija popis unesenih županija
     * @param popisBolesti popis unesenih bolesti
     * @param popisOsoba popis osoba
     * @return
     */
    private static Osoba unosOsobe(BufferedReader unos, Set<Zupanija> popisZupanija, Set<Bolest> popisBolesti, List<Osoba> popisOsoba) throws IOException {
        String ime= unos.readLine();
        String prezime= unos.readLine();
        String datumRodjenja=unos.readLine();
        Integer odabirZupanije=Integer.parseInt(unos.readLine());
        Integer odabirBolesti=Integer.parseInt(unos.readLine());

        List<Osoba> osobeZaPopis=new ArrayList<>();
        Integer dozvoljenaVelicina=0;
        for (int j=0; j<popisOsoba.size(); j=j+1){
            if(popisOsoba.get(j) != null){
                dozvoljenaVelicina=dozvoljenaVelicina+1;
            }
        }

        if (!popisOsoba.isEmpty()){
            Integer brKontakta=Integer.parseInt(unos.readLine());
            if (brKontakta>0){
                for (int j=0; j<brKontakta; j=j+1){
                    Integer odabirOsobe=Integer.parseInt(unos.readLine());
                    osobeZaPopis.add(popisOsoba.get(odabirOsobe-1));
                }
            }
        }

        Zupanija[] zupanije = popisZupanija.toArray(new Zupanija[0]);
        Bolest[] bolesti = popisBolesti.toArray(new Bolest[0]);

        Osoba osoba=new Osoba.Builder(ime)
                .setPrezime(prezime)
                .setDatumRodjenja(datumRodjenja)
                .setZupanija(zupanije[odabirZupanije-1])
                .setZarazenBolescu(bolesti[odabirBolesti-1])
                .setKontaktiraneOsobe(osobeZaPopis)
                .build();

        return osoba;
    }

    /**
     * Provjerava pri unošenju kontakta osobe ako je neki kontakt već prije unesen i baca iznimku
     * DuplikatiKontaktiraneOsobe
     * @param popisOsoba popis unesenih osoba
     * @param osobeZaPopis popis osoba koji se postavlja kao kontakti
     * @param odabirOsobe indeks osobe u popisu osoba koju se želi postaviti kao kontakt
     * @throws DuplikatiKontaktiraneOsobe
     */
    private static void provjeraDuplikata(List<Osoba> popisOsoba, List<Osoba> osobeZaPopis, Integer odabirOsobe)
            throws DuplikatiKontaktiraneOsobe {
        for (int k = 0; k< osobeZaPopis.size(); k=k+1){
            if (osobeZaPopis.get(k)==popisOsoba.get(odabirOsobe-1)){
                throw new DuplikatiKontaktiraneOsobe("Unesen je duplikat! Pokušajte ponovno!");
            }
        }
    }

    /**
     * Traži unos podataka o bolesti, poziva konstruktor s unesenim podacima i vraća novu bolest.
     * @param unos Scanner koji traži unos podataka
     * @param popisSimptoma podaci o simptomima
     * @param popisBolesti popis u koji se spremaju bolesti
     * @return nova bolest
     */
    private static Bolest unosBolesti(BufferedReader unos, Set<Simptom> popisSimptoma, Set<Bolest> popisBolesti) throws IOException {

        Integer vrstaBolesti=Integer.parseInt(unos.readLine());
        Long id = Long.parseLong(unos.readLine());
        String naziv = unos.readLine();
        Integer brSimptomiBolesti = Integer.parseInt(unos.readLine());
        Set<Simptom> simptomiBolesti = new HashSet<>();


        Integer odabir;
        Simptom[] simptomi = popisSimptoma.toArray(new Simptom[0]);

        String tmp=unos.readLine();
        for (int k=0; k<tmp.length(); k=k+1){
            char znak=tmp.charAt(k);
            if (znak==','){
                continue;
            }
            else {
                odabir = Integer.parseInt(String.valueOf(znak));
                simptomiBolesti.add(simptomi[odabir-1]);
            }
        }

        if (!popisBolesti.isEmpty()) {
            try {
                for (int k = 0; k < popisBolesti.size(); k = k + 1) {
                    istiSimptomi(popisBolesti, simptomiBolesti, k);
                }
            } catch (BolestIstihSimptoma ex) {
                logger.error("Unesena je bolest istih simptoma kao već unesena bolest", ex);
                System.out.println(ex.getMessage());
                unosBolesti(unos, popisSimptoma, popisBolesti);
            }
        }

        Bolest bolest = null;
        if (vrstaBolesti == 1) {
            bolest = new Bolest(naziv, id, simptomiBolesti);
        } else if (vrstaBolesti == 2) {
            Virus virus = new Virus(naziv, id, simptomiBolesti);
            bolest = virus;
        }

        return bolest;
    }

    /**
     * Provjera postoji li bolest u popisu bolesti koja ima iste simptome kao
     * bolest koja se unosi
     * @param popisBolesti popis unesenih bolesti
     * @param simptomiBolesti simptomi bolesti koja se unosi
     * @param k varijabla petlje
     * @throws BolestIstihSimptoma
     */
    private static void istiSimptomi(Set<Bolest> popisBolesti, Set<Simptom> simptomiBolesti, int k) {
        if (!popisBolesti.isEmpty()) {
            for (Bolest bolest : popisBolesti){
                if (bolest.getSimptomi().equals(simptomiBolesti)){
                    throw new BolestIstihSimptoma("Postoji bolest istiha simptoma! Unesite novu bolest!");
                }
            }
        }
    }

    /**
     * Ispisuje popis simptoma.
     * @param popisSimptoma Popis simptoma koji se ispisuje
     */
    private static void ispisSimptoma(Set<Simptom> popisSimptoma) {
        int redniBroj=1;
        for (Simptom s: popisSimptoma) {
            System.out.println(redniBroj+". "+s.getNaziv()+ " "+
                    s.getVrijednost().getVrSimptoma());
            redniBroj=redniBroj+1;
        }
    }

    /**
     * Traži unos podataka o simptomima, podatke predaje konstruktoru i vraća novi simptom
     * @param unos Scanner koji traži unos podataka
     * @return novi simptom
     */
    private static Simptom unosSimptoma(BufferedReader unos) throws IOException {
        Long id=Long.parseLong(unos.readLine());
        String naziv= unos.readLine();
        VrijednostSimptoma vrijednostSimptoma = VrijednostSimptoma.valueOf(unos.readLine());
        Simptom simptom=new Simptom(naziv, id, vrijednostSimptoma);
        return simptom;
    }

    /**
     * Traži unos podataka o županiji, podatke predaje konstruktoru i vraća novu županiju
     * @param unos Scanner koji traži unos podataka
     * @return nova županija
     */
    private static Zupanija unosZupanije(BufferedReader unos) throws IOException {

        Long id= Long.parseLong(unos.readLine());
        String naziv=unos.readLine();
        Integer brStanovnika= Integer.parseInt(unos.readLine());
        Integer brZarazenih= Integer.parseInt(unos.readLine());

        Zupanija zupanija=new Zupanija(naziv, id, brStanovnika, brZarazenih);
        return zupanija;
    }

    /**
     * Ispisuje popis županija.
     * @param popis popis županija koji se ispisuje
     */
    private static void ispisZupanija(Set<Zupanija> popis){
        int redniBroj=1;
        for (Zupanija zupanija : popis){
            System.out.println(redniBroj+". "+zupanija.getNaziv());
            redniBroj=redniBroj+1;
        }
    }

    /**
     * Ispisuje popis bolesti.
     * @param popis Popis bolesti koji se ispisuje.
     */
    private static void ispisBolesti(Set<Bolest> popis){
        int redniBroj=1;
        for (Bolest bolest : popis){
            System.out.println(redniBroj+". "+bolest.getNaziv());
            redniBroj=redniBroj+1;
        }
    }

    /**
     * Ispisuje popis osoba.
     * @param popis Popis osoba koji se ispisuje.
     */
    private static void ispisOsoba(List<Osoba> popis){
        for (int i=0; i<popis.size(); i=i+1){
            if(popis.get(i)!=null) {
                System.out.println((i + 1) + ". " + popis.get(i).getIme() + " " +
                        popis.get(i).getPrezime());
            }
        }
    }

}
