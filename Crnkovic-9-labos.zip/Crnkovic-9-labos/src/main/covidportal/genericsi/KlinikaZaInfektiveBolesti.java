package main.covidportal.genericsi;

import main.covidportal.model.Osoba;
import main.covidportal.model.Virus;
import org.w3c.dom.ls.LSOutput;

import java.util.*;


/**
 * Predstavlja entitet klinike za infektivne bolesti koja je određena podacima o virusima
 * i osobama koje su zaražene tim virusima
 * @param <T> Predstavlja tip koji nasljeđuje klasu Virus
 * @param <S> Predstavlja tip koji nasljeđuje klasu Osoba
 */
public class KlinikaZaInfektiveBolesti<T extends Virus, S extends Osoba> {
    private List<T> virusi;
    private List<S> osobe;
    //private Map<T, S> pacijentiPoVirusima;

    /**
     * Instancira podatke o virusima i osobama koje su zaražene tim virusima
     * @param virusi podatak o virusima
     * @param osobe podatak o osobama koje su zaražene virusima
     */
    public KlinikaZaInfektiveBolesti(List<T> virusi, List<S> osobe) {
        this.virusi = virusi;
        this.osobe = osobe;
       /* pacijentiPoVirusima = new HashMap<>();
        for (T v : this.virusi){
            for (S o : this.osobe){
                if (o.getZarazenBolescu().equals(v)){
                    pacijentiPoVirusima.put(v, o);
                }
            }*/

    }

    public List<T> getVirusi() {
        return virusi;
    }

    public List<S> getOsobe() {
        return osobe;
    }

    /**
     * Dodaje virus u listu virusa
     * @param virus podatak o virusu koji se dodaje u listu virusa
     */
    public void dodajUViruse(T virus){
        virusi.add(virus);
    }

    /**
     * DOdaje osobu u listu osoba
     * @param osoba podatak o osobi koja se dodaje u listu osoba
     */
    public void dodajUOsobe(S osoba){
        osobe.add(osoba);
    }

    /**
     * Sortira viruse pomoću lambda izraza
     */
    public void sortViruseLambda(){
        virusi.sort(Comparator.comparing(T::getNaziv).reversed());
    }

    /**
     * Ispisuje listu virusa
     */
    public void printVirusi(){
        for (T t : virusi){
            System.out.println(t.getNaziv());
        }
    }

    /**
     * Sortira viruse pomoću dvije for petlje, bez lambda izraza
     */
    public void sortViruse(){
        for (int i=0; i<virusi.size(); i=i+1){
            for (int j=0; j<virusi.size(); j=j+1){
                if(virusi.get(i).getNaziv().compareTo(virusi.get(j).getNaziv())>0){
                    Collections.swap(virusi, i, j);
                }
            }
        }
    }

}
