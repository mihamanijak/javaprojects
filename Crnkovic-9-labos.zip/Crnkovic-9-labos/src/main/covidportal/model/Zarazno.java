package main.covidportal.model;

/**
 * Sadrži metodu prelazakZarazeNaOsobe
 *
 */
public interface Zarazno {
    public void prelazakZarazeNaOsobe(Osoba o);
}
