package main.covidportal.model;

import main.covidportal.enums.VrijednostSimptoma;

import java.util.Objects;

/**
 * Predstavlja simptom kao entitet koji je definiran s nazivom i vrijednošću koja može biti
 * ČESTO, SREDNJE ili RIJETKO.
 */
public class Simptom extends ImenovaniEntitet{
    private String naziv;
    private Long id;
    private VrijednostSimptoma vrijednost;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Simptom simptom = (Simptom) o;
        return Objects.equals(getNaziv(), simptom.getNaziv()) &&
                Objects.equals(getVrijednost(), simptom.getVrijednost());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNaziv(), getVrijednost());
    }

    /**
     * Inicijalizira podatke o simptomu.
     * @param naziv podatak o nazivu simptoma
     * @param vrijednost podatak o vrijednosti simptoma (ČESTO, SREDNJE, RIJETKO)
     */
    public Simptom(String naziv, Long id, VrijednostSimptoma vrijednost) {
        super(naziv, id);
        this.vrijednost = vrijednost;
    }

    public VrijednostSimptoma getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(VrijednostSimptoma vrijednost) {
        this.vrijednost = vrijednost;
    }
}
