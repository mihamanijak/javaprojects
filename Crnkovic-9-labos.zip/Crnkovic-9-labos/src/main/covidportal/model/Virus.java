package main.covidportal.model;


import java.util.Set;

/**
 * Predstavlja entitet virusa koji je definiran nazivom, simptomima i ima
 * sposobnost da zarazi osobu s kojom je neka osoba bila u kontaktu.
 *
 */
public class Virus extends Bolest implements Zarazno {

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    /**
     * Inicijalizira podatke o nazivu i simptomima virusa.
     * @param naziv podatak o nazivu virusa
     * @param simptomi podatak o simptomima virusa
     */
    public Virus(String naziv, Long id, Set<Simptom> simptomi) {
        super(naziv, id, simptomi);
    }

    /**
     * Overridea metodu iz sučelja Zarazno. Prima osobu koju zarazi virusom.
     * @param o osoba koja se zaražuje virusom
     */
    @Override
    public void prelazakZarazeNaOsobe(Osoba o) {
        o.setZarazenBolescu(this);
    }
}
