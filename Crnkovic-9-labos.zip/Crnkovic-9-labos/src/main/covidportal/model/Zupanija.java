package main.covidportal.model;

import java.util.Objects;

/**
 * Predstavlja entitet županiju koja je definirana nazivom i brojem stanovnika.
 */
public class Zupanija extends ImenovaniEntitet{

    private Integer brojStanovnika;
    private Integer brojZarazenih;
    private Double postotakZarazenih;

    public Integer getBrojZarazenih() {
        return brojZarazenih;
    }

    public void setBrojZarazenih(Integer brojZarazenih) {
        this.brojZarazenih = brojZarazenih;
    }

    public Double getPostotakZarazenih() {
        return postotakZarazenih;
    }

    public void setPostotakZarazenih(Double postotakZarazenih) {
        this.postotakZarazenih = postotakZarazenih;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Zupanija zupanija = (Zupanija) o;
        return Objects.equals(getBrojStanovnika(), zupanija.getBrojStanovnika());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getBrojStanovnika());
    }

    /**
     * Inicijalizira podatke o nazivu i broju stanovnika.
     * @param naziv podatak o nazivu županije
     * @param brojStanovnika podatak o broju stanovnika županije
     * @param brojZarazenih podatak o broju zaraženih stanovnika županije
     */
    public Zupanija(String naziv, Long id, Integer brojStanovnika, Integer brojZarazenih) {
        super(naziv, id);
        this.brojStanovnika = brojStanovnika;
        this.brojZarazenih = brojZarazenih;
        postotakZarazenih= (brojZarazenih.doubleValue()/brojStanovnika.doubleValue())*100;
    }

    public Integer getBrojStanovnika() {
        return brojStanovnika;
    }

    public void setBrojStanovnika(Integer brojStanovnika) {
        this.brojStanovnika = brojStanovnika;
    }
}
