package main.covidportal.model;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * Predstavlja entitet osobe koja je definirana imenom, prezimenom, godinama starosti,
 * županijom stanovanja, bolešću te osobama s kojima je bila u kontaktu.
 *
 */

public class Osoba implements Serializable {
    private Long id;
    private String ime;
    private String prezime;
    private Integer dob;
    private LocalDate datumRodjenja;
    private Zupanija zupanija;
    private Bolest zarazenBolescu;

    public LocalDate getDatumRodjenja() {
        return datumRodjenja;
    }

    private List<Osoba> kontaktiraneOsobe;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Osoba osoba = (Osoba) o;
        return Objects.equals(getIme(), osoba.getIme()) &&
                Objects.equals(getPrezime(), osoba.getPrezime()) &&
                Objects.equals(getStarost(), osoba.getStarost()) &&
                Objects.equals(getZupanija(), osoba.getZupanija()) &&
                Objects.equals(getZarazenBolescu(), osoba.getZarazenBolescu()) &&
                Objects.equals(getKontaktiraneOsobe(), osoba.getKontaktiraneOsobe());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIme(), getPrezime(), getStarost(), getZupanija(), getZarazenBolescu(), getKontaktiraneOsobe());
    }

    /**
     * Skuplja podatke o osobi te poziva konstruktor osobe sa sakupljenim podacima.
     *
     */
    public static class Builder{
        private String ime;
        private String prezime;
        private LocalDate datumRodjenja;
        private Zupanija zupanija;
        private Bolest zarazenBolescu;
        private List<Osoba> kontaktiraneOsobe;
        private Long id;


        /**
         * Inicijalizira podatak o imenu osobe
         * @param ime podatak o imenu osobe
         */
        public Builder(String ime) {
            this.ime = ime;
        }

        public void setIme(String ime) {
            this.ime = ime;
        }

        public Builder setId(Long id) {
            this.id=id;
            return this;
        }
        public Builder setPrezime(String prezime) {
            this.prezime = prezime;
            return this;
        }

        public Builder setDatumRodjenja(String datum) {
            this.datumRodjenja = LocalDate.parse(datum);
            return this;
        }

        public Builder setZupanija(Zupanija zupanija) {
            this.zupanija = zupanija;
            return this;
        }

        public Builder setZarazenBolescu(Bolest zarazenBolescu) {
            this.zarazenBolescu = zarazenBolescu;
            return this;
        }

        public Builder setKontaktiraneOsobe(List<Osoba> kontaktiraneOsobe) {
            this.kontaktiraneOsobe = kontaktiraneOsobe;
            return this;
        }

        /**
         * Gradi osobu sa prikupljenim podacima.
         *
         */
        public Osoba build(){
            //U konstruktoru se poziva metoda prelazakZarazeNaOsobe
            Osoba o=new Osoba(this.id, this.ime, this.prezime, this.datumRodjenja,
                    this.zupanija, this.zarazenBolescu,
                    this.kontaktiraneOsobe);
            return o;
        }
    }

    public Integer getDob(){
        LocalDate localDate = LocalDate.now();
        dob = Period.between(this.datumRodjenja, localDate).getYears();
        return dob;
    }

    public Long getId() {
        return id;
    }

    public List<Osoba> getKontaktiraneOsobe() {
        return kontaktiraneOsobe;
    }

    /**
     * Inicijalizira podatke o osobi.
     * @param ime podatak o imenu osobe
     * @param prezime podatak o prezimenu osobe
     * @param datumRodjenja podatak o datumu rodjenja osobe
     * @param zupanija podatak o županiji prebivališta osobe
     * @param zarazenBolescu podatak o bolesti osobe
     * @param kontaktiraneOsobe podatak o kontaktima osobe
     */
    private Osoba(Long id, String ime, String prezime, LocalDate datumRodjenja, Zupanija zupanija,
                  Bolest zarazenBolescu, List<Osoba> kontaktiraneOsobe) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.datumRodjenja = datumRodjenja;
        this.zupanija = zupanija;
        this.zarazenBolescu = zarazenBolescu;
        this.kontaktiraneOsobe = kontaktiraneOsobe;

        if (this.zarazenBolescu instanceof Virus) {
            for (int i = 0; i < kontaktiraneOsobe.size(); i = i + 1) {
                ((Virus) this.zarazenBolescu).prelazakZarazeNaOsobe(kontaktiraneOsobe.get(i));
            }
        }
        getDob();
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Integer getStarost() {
        return dob;
    }


    public Zupanija getZupanija() {
        return zupanija;
    }

    public void setZupanija(Zupanija zupanija) {
        this.zupanija = zupanija;
    }

    public Bolest getZarazenBolescu() {
        return zarazenBolescu;
    }

    public void setZarazenBolescu(Bolest zarazenBolescu) {
        this.zarazenBolescu = zarazenBolescu;
    }

    /*public List<Osoba> getKontaktiraneOsobe() {
        return kontaktiraneOsobe;
    }*/

    public void setKontaktiraneOsobe(List<Osoba> kontaktiraneOsobe) { this.kontaktiraneOsobe = kontaktiraneOsobe; }

    /**
     * Dodaje osobu u popis kontakta
     * @param o osoba koja se dodaje u popis kontakta
     */
    public void DodajKontakt(Osoba o){
        kontaktiraneOsobe.add(o);
        /*Osoba[] popisKontakta=new Osoba[kontaktiraneOsobe.size()+1];
        if (kontaktiraneOsobe.length > 0) {
            for (int i = 0; i < (kontaktiraneOsobe.length); i = i + 1) {
                popisKontakta[i] = kontaktiraneOsobe[i];
            }
            popisKontakta[kontaktiraneOsobe.length]=o;

        }
        else {
            popisKontakta[0]=o;
        }
        kontaktiraneOsobe=popisKontakta;*/
    }

    /**
     * Prolazi kroz popis kontakta osobe i stavlja osobu u kontakte svojih kontakta
     */
    public void upari (){
        for (int i=0; i<kontaktiraneOsobe.size(); i=i+1){
            kontaktiraneOsobe.get(i).DodajKontakt(this);
        }
    }

    /*public void ispisKontakta(){
        for (int i=0; i< kontaktiraneOsobe.length; i+1)
    }*/

}
