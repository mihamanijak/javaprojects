package main.covidportal.model;

import java.io.Serializable;
import java.io.SerializablePermission;
import java.util.Objects;
import java.util.Set;

/**
 * Predstavlja entitet bolesti koja je definirana nazivom i popisom simptoma.
 *
 *
 */

public class Bolest extends ImenovaniEntitet {
    private Set<Simptom> simptomi;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Bolest)) return false;
        Bolest bolest = (Bolest) o;
        return Objects.equals(getSimptomi(), bolest.getSimptomi());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSimptomi());
    }

    /**
     * Inicijalizira podatke o bolesti.
     * @param naziv podatak o nazivu bolesti
     * @param simptomi podatak o simptomima bolesti
     */
    public Bolest(String naziv, Long id, Set<Simptom> simptomi) {
        super(naziv, id);
        this.simptomi = simptomi;
    }

    public Set<Simptom> getSimptomi() {
        return simptomi;
    }

    public void setSimptomi(Set<Simptom> simptomi) {
        this.simptomi = simptomi;
    }
}
