package main.resources;

import main.covidportal.enums.VrijednostSimptoma;
import main.covidportal.model.*;
import main.java.pocetniEkran.Main;

import javax.swing.plaf.nimbus.State;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.Date;
import java.util.stream.Collectors;

public class BazaPodataka {


    private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    public Connection otvoriVezu() throws IOException, SQLException, ClassNotFoundException {
        Properties properties = new Properties();
        properties.load(new FileReader("dat\\database.properties"));

        String url = properties.getProperty("urlBaze");
        String korisnickoIme= properties.getProperty("korisnickoIme");
        String lozinka = properties.getProperty("lozinka");

        connection = DriverManager.getConnection(url, korisnickoIme, lozinka);

        return connection;
    }

    public void zatvoriVezu() throws SQLException {
        if(!connection.isClosed()){
            connection.close();
        }
    }

    public List<Bolest> findBolestiSimptoma(Simptom simptom) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT DISTINCT BOLEST.*\n" +
                "\n" +
                "FROM BOLEST INNER JOIN\n" +
                "\n" +
                "     BOLEST_SIMPTOM ON BOLEST.ID = BOLEST_SIMPTOM.BOLEST_ID\n" +
                "\n" +
                "WHERE BOLEST_SIMPTOM.SIMPTOM_ID = "+simptom.getId()+";");

        List<Bolest> bolestiSimptoma = new ArrayList<>();

        while(resultSet.next()){
            Statement newStatement= connection.createStatement();
            Set<Simptom> simptomiBolesti= new HashSet<>();
            Long idBolesti = resultSet.getLong(1);
            String nazivBolesti = resultSet.getString("naziv");
            Boolean isVirus = resultSet.getBoolean(3);

            ResultSet tmpSimptomi = newStatement.executeQuery("SELECT * FROM BOLEST_SIMPTOM" +
                    " WHERE BOLEST_ID = "+idBolesti.toString());

            while(tmpSimptomi.next()){
                /*Long idSimptoma = resultSet.getLong(1);
                String nazivSimptoma = resultSet.getString("naziv");
                String vrijednost = resultSet.getString("vrijednost");

                Simptom simptom = new Simptom(nazivSimptoma, idSimptoma,
                        VrijednostSimptoma.valueOf(vrijednost));
                simptomiBolesti.add(simptom);*/
                simptomiBolesti.add(findSimptom(tmpSimptomi.getLong("simptom_id")));
            }

            if (isVirus == true){
                Virus virus = new Virus(nazivBolesti, idBolesti, simptomiBolesti);
                bolestiSimptoma.add(virus);
            }
            else {
                Bolest bolest = new Bolest(nazivBolesti, idBolesti, simptomiBolesti);
                bolestiSimptoma.add(bolest);
            }

        }
        return bolestiSimptoma;
    }

    public List<Simptom> getSimptomi() throws SQLException {
        List<Simptom> simptomi= new ArrayList<>();
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM SIMPTOM");
        while(resultSet.next()){
            Long id = resultSet.getLong(1);
            String naziv = resultSet.getString("naziv");
            String vrijednost = resultSet.getString("vrijednost");

            Simptom simptom = new Simptom(naziv, id, VrijednostSimptoma.valueOf(vrijednost.toUpperCase()));
            simptomi.add(simptom);
        }
        return simptomi;
    }

    public Simptom findSimptom(Long id) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM SIMPTOM WHERE ID = "+id.toString());

        resultSet.next();
        String naziv = resultSet.getString("naziv");
        String vrijednost = resultSet.getString("vrijednost");

        return new Simptom(naziv, id, VrijednostSimptoma.valueOf(vrijednost.toUpperCase()));

    }

    public void dodajSimptom(Simptom simptom) throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("INSERT INTO SIMPTOM(NAZIV, VRIJEDNOST) " +
                "VALUES ('"+simptom.getNaziv()+"', '"+simptom.getVrijednost().toString()+"')");

    }

    public List<Bolest> getBolesti() throws SQLException {
        List<Bolest> bolesti = new ArrayList<>();

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM BOLEST");
        while(resultSet.next()){
            Statement newStatement= connection.createStatement();
            Set<Simptom> simptomiBolesti= new HashSet<>();
            Long idBolesti = resultSet.getLong(1);
            String nazivBolesti = resultSet.getString("naziv");
            Boolean isVirus = resultSet.getBoolean(3);

            ResultSet tmpSimptomi = newStatement.executeQuery("SELECT * FROM BOLEST_SIMPTOM" +
                    " WHERE BOLEST_ID = "+idBolesti.toString());

            while(tmpSimptomi.next()){
                /*Long idSimptoma = resultSet.getLong(1);
                String nazivSimptoma = resultSet.getString("naziv");
                String vrijednost = resultSet.getString("vrijednost");

                Simptom simptom = new Simptom(nazivSimptoma, idSimptoma,
                        VrijednostSimptoma.valueOf(vrijednost));
                simptomiBolesti.add(simptom);*/
                simptomiBolesti.add(findSimptom(tmpSimptomi.getLong("simptom_id")));
            }

            if (isVirus == true){
                Virus virus = new Virus(nazivBolesti, idBolesti, simptomiBolesti);
                bolesti.add(virus);
            }
            else {
                Bolest bolest = new Bolest(nazivBolesti, idBolesti, simptomiBolesti);
                bolesti.add(bolest);
            }

        }
        return bolesti;
    }

    public Bolest findBolest(Long id) throws SQLException {
        Bolest bolest;
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM BOLEST WHERE ID = "+id.toString());
        resultSet.next();
        Statement newStatement = connection.createStatement();
        ResultSet tmpSimptomi = newStatement.executeQuery(
                "SELECT * FROM BOLEST_SIMPTOM WHERE BOLEST_ID = "+id.toString());

        Set<Simptom> simptomiBolesti = new HashSet<>();
        String nazivBolesti = resultSet.getString("naziv");
        Boolean isVirus = resultSet.getBoolean(3);

        while (tmpSimptomi.next()){
            simptomiBolesti.add(findSimptom(tmpSimptomi.getLong("simptom_id")));
        }

        if (isVirus == true){
            bolest = new Virus(nazivBolesti, id, simptomiBolesti);
        }
        else {
            bolest = new Bolest(nazivBolesti, id, simptomiBolesti);
        }

        return bolest;
    }

    public void dodajBolest(Bolest bolest) throws SQLException {
        Statement statement = connection.createStatement();
        Boolean isVirus = false;
        if (bolest instanceof Virus){
            isVirus = true;
        }
        statement.executeQuery("INSERT INTO BOLEST(NAZIV, VIRUS) VALUES ('"+bolest.getNaziv()+
                "', '"+isVirus.toString()+"');");

        for (Simptom simptom : bolest.getSimptomi()){
            statement.executeQuery("INSERT INTO BOLEST_SIMPTOM(BOLEST_ID, SIMPTOM_ID) VALUES ("+bolest.getId()+
                    ", "+simptom.getId()+");");
        }
    }

    public List<Zupanija>  getZupanije() throws SQLException {
        Statement statement = connection.createStatement();
        List<Zupanija> zupanije = new ArrayList<>();

        ResultSet resultSet = statement.executeQuery("SELECT * FROM ZUPANIJA");
        while(resultSet.next()){
            Long id = resultSet.getLong(1);
            String naziv = resultSet.getString("naziv");
            Integer brStanovnika = resultSet.getInt("broj_stanovnika");
            Integer brZarazenih = resultSet.getInt("broj_zarazenih_stanovnika");

            Zupanija zupanija = new Zupanija(naziv, id, brStanovnika, brZarazenih);
            zupanije.add(zupanija);
        }

        return zupanije;
    }

    public Zupanija findZupanija(Long id) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM ZUPANIJA WHERE ID = "+id.toString());
        resultSet.next();
        String naziv = resultSet.getString("naziv");
        Integer brStanovnika = resultSet.getInt("broj_stanovnika");
        Integer brZarazenih = resultSet.getInt("broj_zarazenih_stanovnika");

        return new Zupanija(naziv, id, brStanovnika, brZarazenih);
    }

    public void dodajZupaniju(Zupanija zupanija) throws SQLException {
        Statement statement = connection.createStatement();
        statement.executeQuery("INSERT INTO ZUPANIJA(NAZIV, BROJ_STANOVNIKA,\n" +
                "BROJ_ZARAZENIH_STANOVNIKA) VALUES('"+zupanija.getNaziv()+"', "+zupanija
                .getBrojStanovnika().toString()+","+zupanija.getBrojZarazenih().toString()+");");
    }

    public List<Osoba> getOsobe() throws SQLException {
        Statement statement = connection.createStatement();
        List<Osoba> osobe = new ArrayList<>();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM OSOBA");

        while(resultSet.next()){
            List<Osoba> kontaktiraneOsobe = new ArrayList<>();
            Osoba.Builder builder = new Osoba.Builder(resultSet.getString("ime"));
            Statement newStatement= connection.createStatement();
            ResultSet kontakti = newStatement.executeQuery("SELECT * FROM KONTAKTIRANE_OSOBE WHERE OSOBA_ID = "
                            +resultSet.getLong(1));

            builder.setPrezime(resultSet.getString("prezime"))
                    .setId(resultSet.getLong(1))
                    .setDatumRodjenja(resultSet.getString("datum_rodjenja"))
                    .setZupanija(findZupanija(resultSet.getLong("zupanija_id")))
                    .setZarazenBolescu(findBolest(resultSet.getLong("bolest_id")));

            while (kontakti.next()){
                kontaktiraneOsobe.add(findOsoba(kontakti.getLong("kontaktirana_osoba_id")));
            }
            builder.setKontaktiraneOsobe(kontaktiraneOsobe);
            osobe.add(builder.build());

        }

        return osobe;
    }

    public Osoba findOsoba(Long id) throws SQLException {
        Statement statement = connection.createStatement();
        List<Osoba> kontaktiraneOsobe = new ArrayList<>();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM OSOBA WHERE ID = "+id.toString());
        resultSet.next();
        Osoba.Builder builder = new Osoba.Builder(resultSet.getString("ime"));
        builder.setPrezime(resultSet.getString("prezime"))
                .setId(resultSet.getLong(1))
                .setDatumRodjenja(resultSet.getString("datum_rodjenja"))
                .setZupanija(findZupanija(resultSet.getLong("zupanija_id")))
                .setZarazenBolescu(findBolest(resultSet.getLong("bolest_id")));

        ResultSet kontakti = statement.executeQuery("SELECT * FROM KONTAKTIRANE_OSOBE WHERE OSOBA_ID = "
        +resultSet.getLong(1));

        while (kontakti.next()){
            kontaktiraneOsobe.add(findOsoba(kontakti.getLong("kontaktirana_osoba_id")));
        }

        builder.setKontaktiraneOsobe(kontaktiraneOsobe);
        return builder.build();
    }

    public void dodajOsobu(Osoba osoba) throws SQLException {
        Statement statement = connection.createStatement();


        statement.execute("INSERT INTO OSOBA(ID, IME, PREZIME, DATUM_RODJENJA, ZUPANIJA_ID,\n" +
                "BOLEST_ID) VALUES ('"+osoba.getId()+"','"+osoba.getIme()+"', " +
                "'"+osoba.getPrezime()+"', " +
                "'"+osoba.getDatumRodjenja().toString()+"', " +
                ""+osoba.getZupanija().getId()+", "+osoba.getZupanija().getId()+");");
        List<Long> kontaktiId = osoba.getKontaktiraneOsobe().stream()
                .map(Osoba::getId).collect(Collectors.toList());

        for (Long id : kontaktiId){
            Statement newStatement = connection.createStatement();
            newStatement.execute("INSERT INTO KONTAKTIRANE_OSOBE VALUES("+osoba.getId()+", "+id+");");
        }
    }
}
